/*
 * cgi_utilities.h
 *
 *  Created on: Sep 28, 2017
 *      Author: CNTHXIE
 */

#ifndef WEBSERVER_LWIP_CGI_UTILITIES_H_
#define WEBSERVER_LWIP_CGI_UTILITIES_H_

void int2cstr (int val, char *str_ary);
void double2cstr (double val, char *str_ary);

#endif /* WEBSERVER_LWIP_CGI_UTILITIES_H_ */
